drop database if exists test_app;
create database test_app;
use test_app;