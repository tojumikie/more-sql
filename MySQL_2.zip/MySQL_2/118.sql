# select distinct author_lname from books;

# select distinct concat(author_fname, ' ', author_lname) from books;

select distinct author_fname, author_lname from books;