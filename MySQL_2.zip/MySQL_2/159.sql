insert into people(name, birthdate, birthtime, birthdt) values
('Larry', '1943-12-25', '04:10:42', '1943-12-25 04:10:42');