insert into cats(name, age) values
	('Charlie', 17);
	
insert into cats(name, age) values
	('Connie', 10);

select * from cats;