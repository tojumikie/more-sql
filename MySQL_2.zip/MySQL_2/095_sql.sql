create table cats
(
	cat_id int not null auto_increment,
	name varchar(100),
	age int,
	primary key(cat_id)
);